import axios from 'axios';

const api = axios.create({
    baseURL: 'http://10.135.60.104:3000/api' //bota o seu ip(ipconfig no terminal e achar o ipv4)
});

export default api;

