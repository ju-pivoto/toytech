//IMPORTACOES NECESSARIAS PARA O FUNCIONAMENTO DO PROJETO
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  ImageBackground,
  Alert
} from 'react-native';

import QRCodeScannerModal from '../QRCodeScannerModal';
import { Ionicons } from '@expo/vector-icons';
import api from '../src/services/api';

export default function SoliEntrada({ navigation, route }) {
  const [product, setProduct] = useState(null);
  const [code, setCode] = useState('');
  const [quantity, setQuantity] = useState('');
  const [isScannerOpen, setIsScannerOpen] = useState(false);

  useEffect(() => {
    if (route?.params?.produto) {
      const prod = route.params.produto;
      setProduct(prod);
      setCode(String(prod.code || prod.id || ''));
    } else {
      api.get('/products/1')
        .then(res => {
          setProduct(res.data);
          setCode(String(res.data.code || res.data.id || ''));
        })
        .catch(console.log);
    }
  }, [route?.params?.produto]);

  const handleReadQRCode = (data) => {
    setIsScannerOpen(false);
    setCode(data);

  };

  {/*NENHUM PRODUTO SELECIONADO */}
  const confirmarEntrada = async () => {
    if (!product) {
      Alert.alert('Erro', 'Nenhum produto selecionado.');
      return;
    }

    {/*SE A QUANTIDADE FOR MENOR E IGUAL A 0*/}
    const qtd = Number(quantity);

    if (!quantity || isNaN(qtd) || qtd <= 0) {
      Alert.alert('Erro', 'Insira uma quantidade válida.');
      return;
    }

    {/*SE A QUANTIDADE DO PRODUTO ENTROU */}
    try {
      await api.post('/stock/move', {
        productId: product.id,
        type: 'Entrada',
        quantity: parseInt(quantity),
      });

      Alert.alert('Sucesso', 'Entrada registrada com sucesso!', [
        {
          text: 'OK',
          onPress: () => navigation.goBack(),
        },
      ]);
      setQuantity('');
    } catch (error) {
      Alert.alert(
        'Erro',
        error.response?.data?.message || 'Erro ao registrar entrada.'
      );
    }
  };

  //Estoque final
  const estoqueAtual = Number(product?.stock || product?.estoque || 0);
  const qtdInserida = Number(quantity || 0);
  const estoqueFinal = estoqueAtual + qtdInserida;

  {/*IMAGEM DE FUNDO */}
  return (
    <ImageBackground
      source={require('../assets/imgs/fundo.png')}
      style={styles.background}
      resizeMode="cover"
    >
      <ScrollView
        style={styles.container}
        showsVerticalScrollIndicator={false}
      >
        {/*BOTAO PRA VOLTAR A PAGINA ANTERIOR */}
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.botaovoltar}
        >
          <Ionicons
            name="arrow-back"
            size={30}
            color="#fff"
          />
        </TouchableOpacity>

        {/*Header */}
        <View style={styles.header}>
          <Text style={styles.title}>
            Entrada de Estoque
          </Text>

          <Text style={styles.subtitle}>
            Registre produtos rapidamente
          </Text>
        </View>

        {/*Qr code */}
        <TouchableOpacity
          style={styles.qrButton}
          onPress={() => setIsScannerOpen(true)}
        >
          <View style={styles.qrContent}>
            <Ionicons
              name="qr-code-outline"
              size={32}
              color="#fff"
            />

            <View>
              <Text style={styles.qrTitle}>
                Ler QR Code
              </Text>

              <Text style={styles.qrSubtitle}>
                Escanear produto
              </Text>
            </View>
          </View>

          <Ionicons
            name="chevron-forward"
            size={22}
            color="#fff"
          />
        </TouchableOpacity>

        <QRCodeScannerModal
          visible={isScannerOpen}
          onClose={() => setIsScannerOpen(false)}
          onReadCode={handleReadQRCode}
        />

        {/*Produto */}
        <Text style={styles.sectionTitle}>
          Produto Encontrado
        </Text>

        <View style={styles.productCard}>
          <View style={styles.productIcon}>
            <Ionicons
              name="cube"
              size={28}
              color="#3B82F6"
            />
          </View>

          <View style={{ flex: 1 }}>
            <Text style={styles.productName}>
              {product ? product.name : 'Nenhum produto selecionado'}
            </Text>

            <Text style={styles.productCode}>
              Código: {code || '-'}
            </Text>

            <Text style={styles.productStock}>
              Estoque Atual: {estoqueAtual}
            </Text>
          </View>
        </View>

        {/*Quantidade */}
        <Text style={styles.sectionTitle}>
          Quantidade
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Digite a quantidade"
          placeholderTextColor="#94A3B8"
          keyboardType="numeric"
          value={quantity}
          onChangeText={setQuantity}
        />

        {/*resumo */}

        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>
            Resumo da Entrada
          </Text>

          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>
              Produto
            </Text>

            <Text style={styles.summaryValue}>
              {product ? product.name : 'Nenhum produto selecionado'}
            </Text>
          </View>

          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>
              Quantidade
            </Text>

            <Text style={styles.summaryValue}>
              {quantity || 0}
            </Text>
          </View>

          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>
              Estoque Final
            </Text>

            <Text style={styles.summaryValueGreen}>
              {estoqueFinal}
            </Text>
          </View>
        </View>

        {/*botao pra confirmar */}
        <TouchableOpacity
          style={styles.confirmButton}
          onPress={confirmarEntrada}
        >
          <Ionicons
            name="checkmark-circle"
            size={24}
            color="#fff"
          />

          <Text style={styles.confirmText}>
            Confirmar Entrada
          </Text>
        </TouchableOpacity>

        <View style={{ height: 40 }} />
      </ScrollView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: 'transparent',
    paddingHorizontal: 20,
  },
  botaovoltar: {
    marginTop: 20,
    alignSelf: 'flex-start',
  },
  header: {
    marginTop: 20,
  },
  title: {
    color: '#fff',
    fontSize: 30,
    fontWeight: 'bold',
  },
  subtitle: {
    color: '#ffffff',
    marginTop: 5,
    fontSize: 15,
  },
  qrButton: {
    backgroundColor: '#3c5fbc',
    borderRadius: 25,
    padding: 22,
    marginTop: 30,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  qrContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  qrTitle: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  qrSubtitle: {
    color: '#ffffff',
    marginTop: 3,
  },
  sectionTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 35,
    marginBottom: 15,
  },
  productCard: {
    backgroundColor: '#1E293B',
    borderRadius: 22,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  productIcon: {
    width: 65,
    height: 65,
    backgroundColor: '#172554',
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  productName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  productCode: {
    color: '#ffffff',
    marginTop: 5,
  },
  productStock: {
    color: '#22C55E',
    marginTop: 8,
    fontWeight: 'bold',
  },
  input: {
    backgroundColor: '#1E293B',
    height: 65,
    borderRadius: 18,
    paddingHorizontal: 20,
    color: '#ffffff',
    fontSize: 18,
  },
  summaryCard: {
    backgroundColor: '#1E293B',
    borderRadius: 22,
    padding: 22,
    marginTop: 35,
  },
  summaryTitle: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  summaryLabel: {
    color: '#ffffff',
    fontSize: 15,
  },
  summaryValue: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  summaryValueGreen: {
    color: '#22C55E',
    fontWeight: 'bold',
  },
  confirmButton: {
    backgroundColor: '#16A34A',
    height: 65,
    borderRadius: 22,
    marginTop: 35,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  confirmText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});