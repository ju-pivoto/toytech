//IMPORTACOES NECESSARIAS PARA O FUNCIONAMENTO DA TELA
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ImageBackground } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import api from '../src/services/api';

export default function Historico() {
  const [history, setHistory] = useState([]);

  const loadHistory = async () => {
    try {
      const response = await api.get('historico');
      const formattedData = [...response.data].sort((a, b) => b.id - a.id);
      setHistory(formattedData);
    } catch (error) {
      console.log('Erro ao carregar histórico:', error);
    }
  };

  useEffect(() => {
    loadHistory();
  }, []);


  {/*IMAGEMD E FUNDO */}
  return (
    <ImageBackground
      source={require('../assets/imgs/fundo.png')}
      style={styles.container}
      resizeMode="cover"
    >
      {/*HISTORICO-ENTRADA ESAIDA DOS PRODUTOS */}
      <Text style={styles.title}>Histórico Recente</Text>

      {history.length === 0 ? (
        <Text style={styles.emptyText}>Nenhuma movimentação registrada.</Text>
      ) : (
        <FlatList
          data={history}
          scrollEnabled={false}
          keyExtractor={(item, index) => (item.id ? item.id.toString() : index.toString())}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={styles.lineItem}>
              <View style={styles.leftContent}>
                <Ionicons
                  name={item.type === 'Entrada' ? 'checkmark-circle' : 'close-circle'}
                  size={22}
                  color={item.type === 'Entrada' ? '#22C55E' : '#EF4444'}
                />
                <Text style={styles.productText} numberOfLines={1}>
                  {item.product}
                </Text>
                <Text
                  style={[
                    styles.typeTag,
                    { color: item.type === 'Entrada' ? '#22C55E' : '#EF4444' },
                  ]}
                >
                  ({item.type})
                </Text>
              </View>

              <Text style={styles.rightContent}>
                {item.quantity ? `${item.quantity} un • ` : ''}{item.date}
              </Text>
            </View>
          )}
        />
      )}
    </ImageBackground>
  );
}

{/*ESTILO DA INTERFACE */}
const styles = StyleSheet.create({
  container: {
    flex: 1, 
    paddingTop: 50, 
    paddingHorizontal: 16,
  },
  title: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  emptyText: {
    color: '#94A3B8',
    fontSize: 14,
    fontStyle: 'italic',
    marginTop: 5,
  },
  lineItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(30, 41, 59, 0.9)', 
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 8,
  },
  leftContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
    marginRight: 10,
  },
  productText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
    flexShrink: 1,
  },
  typeTag: {
    fontSize: 13,
    fontWeight: 'bold',
  },
  rightContent: {
    color: '#94A3B8',
    fontSize: 13,
  },
});