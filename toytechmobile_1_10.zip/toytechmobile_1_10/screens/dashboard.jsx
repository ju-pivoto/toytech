//Importacoes necessarias para o funcionamento da tela
import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import api from '../src/services/api';
import Historico from './historico';

export default function Dashboard({ navigation }) {
  const [dashboardData, setDashboardData] = useState({
    estoque: 0,
    totalEntradas: 0,
    totalSaidas: 0,
  });

  const loadDashboard = async () => {
    try {
      const response = await api.get('/dashboard');
      console.log('Dados do Dashboard:', response.data);
      setDashboardData(response.data);
    } catch (error) {
      console.log('Erro ao carregar Dashboard:', error);
    }
  };

  useFocusEffect(
    useCallback(() => {
      loadDashboard();
    }, [])
  );

  return (
    <ScrollView 
      style={styles.container} 
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingBottom: 40 }}
    >

      {/*HEADER*/}
      <View style={styles.header}>
        <View>
          <Text style={styles.welcome}>Bem-vindo a ToyTech!</Text>
          <Text style={styles.userName}>Sistema de Estoque</Text>
        </View>
        <TouchableOpacity style={styles.notification}>
          <Ionicons name="notifications-outline" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
      {/*CARD PRINCIPAL-ESTOQUE */}
      <View style={styles.balanceCard}>
        <Text style={styles.balanceLabel}>Produtos em Estoque</Text>
        <Text style={styles.balanceValue}>{dashboardData.estoque}</Text>
        <View style={styles.balanceFooter}>
          <Ionicons name="trending-up" size={18} color="#22C55E" />
          <Text style={styles.balanceGrowth}>Atualizado com o BD</Text>
        </View>
      </View>
      {/*CARDS-ENTRADA E SAIDA */}
      <View style={styles.cardsContainer}>
        <View style={styles.smallCard}>
          <View style={styles.iconBlue}>
            <Ionicons name="arrow-down-circle" size={24} color="#22C55E" />
          </View>
          <Text style={styles.cardNumber}>{dashboardData.totalEntradas}</Text>
          <Text style={styles.cardLabel}>Entradas</Text>
        </View>

        <View style={styles.smallCard}>
          <View style={styles.iconRed}>
            <Ionicons name="arrow-up-circle" size={24} color="#EF4444" />
          </View>
          <Text style={styles.cardNumber}>{dashboardData.totalSaidas}</Text>
          <Text style={styles.cardLabel}>Saídas</Text>
        </View>
      </View>

      {/*ATALHOS */}
      <Text style={styles.sectionTitle}>Operações</Text>

      {/*PRODUTOS */}
      <TouchableOpacity style={styles.actionButtonBlue} onPress={() => navigation.navigate('Produtos')}>
        <View style={styles.buttonContent}>
          <Ionicons name="cube-outline" size={26} color="#fff" />
          <View>
            <Text style={styles.buttonTitle}>Produtos</Text>
            <Text style={styles.buttonSubtitle}>Visualizar estoque completo</Text>
          </View>
        </View>
        <Ionicons name="chevron-forward" size={22} color="#fff" />
      </TouchableOpacity>
      {/*ENTRADA */}
      <TouchableOpacity style={styles.actionButtonGreen} onPress={() => navigation.navigate('Entrada')}>
        <View style={styles.buttonContent}>
          <Ionicons name="arrow-down-circle-outline" size={26} color="#fff" />
          <View>
            <Text style={styles.buttonTitle}>Entrada de Estoque</Text>
            <Text style={styles.buttonSubtitle}>Registrar novos produtos</Text>
          </View>
        </View>
        <Ionicons name="chevron-forward" size={22} color="#fff" />
      </TouchableOpacity>

      {/*SAIDA */}
      <TouchableOpacity style={styles.actionButtonRed} onPress={() => navigation.navigate('Saida')}>
        <View style={styles.buttonContent}>
          <Ionicons name="arrow-up-circle-outline" size={26} color="#fff" />
          <View>
            <Text style={styles.buttonTitle}>Saída de Estoque</Text>
            <Text style={styles.buttonSubtitle}>Registrar retirada</Text>
          </View>
        </View>
        <Ionicons name="chevron-forward" size={22} color="#fff" />
      </TouchableOpacity>

      {/*HISTORICO-MOVIMENTACOES */}
      <Historico />

    </ScrollView>
  );
}

{/*INTERFACE-ESTILO */}
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#2640b7', paddingHorizontal: 20 },
  header: { marginTop: 60, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  welcome: { color: '#ffffff', fontSize: 15 },
  userName: { color: '#fff', fontSize: 28, fontWeight: 'bold', marginTop: 3 },
  notification: { width: 50, height: 50, backgroundColor: '#1E293B', borderRadius: 15, justifyContent: 'center', alignItems: 'center' },
  balanceCard: { backgroundColor: '#2563EB', borderRadius: 30, padding: 25, marginTop: 30 },
  balanceLabel: { color: '#DBEAFE', fontSize: 16 },
  balanceValue: { color: '#fff', fontSize: 42, fontWeight: 'bold', marginTop: 10 },
  balanceFooter: { flexDirection: 'row', alignItems: 'center', marginTop: 12 },
  balanceGrowth: { color: '#DCFCE7', marginLeft: 6, fontWeight: '600' },
  cardsContainer: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 25 },
  smallCard: { backgroundColor: '#1E293B', width: '48%', borderRadius: 22, padding: 20 },
  iconBlue: { width: 50, height: 50, backgroundColor: '#172554', borderRadius: 15, justifyContent: 'center', alignItems: 'center' },
  iconRed: { width: 50, height: 50, backgroundColor: '#450A0A', borderRadius: 15, justifyContent: 'center', alignItems: 'center' },
  cardNumber: { color: '#fff', fontSize: 28, fontWeight: 'bold', marginTop: 15 },
  cardLabel: { color: '#94A3B8', marginTop: 5 },
  sectionTitle: { color: '#fff', fontSize: 22, fontWeight: 'bold', marginTop: 35, marginBottom: 18 },
  actionButtonBlue: { backgroundColor: '#2563EB', borderRadius: 24, padding: 20, marginBottom: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  actionButtonGreen: { backgroundColor: '#16A34A', borderRadius: 24, padding: 20, marginBottom: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  actionButtonRed: { backgroundColor: '#DC2626', borderRadius: 24, padding: 20, marginBottom: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  buttonContent: { flexDirection: 'row', alignItems: 'center', gap: 15 },
  buttonTitle: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  buttonSubtitle: { color: '#E2E8F0', marginTop: 3, fontSize: 13 },
});
