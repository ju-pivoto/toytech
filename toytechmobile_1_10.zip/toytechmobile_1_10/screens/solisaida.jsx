//IMPORTACOES NECESSARIAS PARA O FUNCIONAMENTO DO PROJETO
import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    ImageBackground,
    Alert
} from 'react-native';

import api from '../src/services/api';
import QRCodeScannerModal from '../QRCodeScannerModal';
import { Ionicons } from '@expo/vector-icons';

export default function SoliSaida({ navigation, route }) {
    const [quantity, setQuantity] = useState('');
    const [product, setProduct] = useState(null);
    const [isScannerOpen, setIsScannerOpen] = useState(false);

    useEffect(() => {
        if (route?.params?.produto) {
            setProduct(route.params.produto);
        } else {
            // Carrega produto inicial padrão caso não venha por parâmetro
            api.get('/products/1')
                .then(res => setProduct(res.data))
                .catch(err => console.log('Erro ao carregar produto inicial:', err));
        }
    }, [route?.params?.produto]);
    
    {/*QRCODE */}
    async function handleReadQRCode(data) {
        setIsScannerOpen(false);

        try {
            const response = await api.get(`/products/${data}`);
            setProduct(response.data);

            Alert.alert(
                'Produto encontrado',
                `${response.data.name || response.data.nome}\nEstoque: ${response.data.stock ?? response.data.produto_quantidade ?? 0}`
            );
        } catch (error) {
            console.log(error);
            setProduct(null);
            Alert.alert(
                'Erro',
                'Produto não encontrado.'
            );
        }
    }

    {/*SE NAO SELECIONAR NEHUM PRODUTO */}
    async function confirmarSaida() {
        const qtdNum = Number(quantity);

        if (!product) {
            Alert.alert('Erro', 'Nenhum produto selecionado.');
            return;
        }

        {/*SE A QUANTIDADE FOR IGUAL E MENOR QUE 0 */}
        if (!quantity || isNaN(qtdNum) || qtdNum <= 0) {
            Alert.alert('Erro', 'Insira uma quantidade válida.');
            return;
        }

        {/*SE TENTAR TIRAR DO ESTOQUE UMA QUANTIDADE QUE SUPERA QUANTIDADE AYUAL  */}
        const estoqueAtual = product.stock ?? product.produto_quantidade ?? 0;

        if (qtdNum > estoqueAtual) {
            Alert.alert('Erro', 'Quantidade solicitada é maior que o estoque atual.');
            return;
        }
        
        {/*SE DER CERTO A RETIRADA DO PRODUTO */}
        try {
            await api.post('/stock/move', {
                productId: product.id || product.produto_id,
                type: 'Saída',
                quantity: qtdNum,
            });

            Alert.alert('Sucesso', 'Saída realizada com sucesso!', [
                {
                    text: 'OK',
                    onPress: () => {
                        setQuantity('');
                        navigation.goBack();
                    }
                },
            ]);
        } catch (error) {
            Alert.alert('Erro', error.response?.data?.message || 'Erro ao registrar saída.');
        }
    }

    //calculo do estoque que sobra
    const estoqueAtual = product?.stock ?? product?.produto_quantidade ?? 0;
    const remainingStock = estoqueAtual - Number(quantity || 0);

    {/*IMAGEM DE FUNDO */}
    return (
        <ImageBackground
            source={require('../assets/imgs/fundo.png')}
            style={styles.background}
            resizeMode="cover"
        >
            <ScrollView
                style={styles.container}
                showsVerticalScrollIndicator={false}
            >
                {/*botao pra voltar */}
                <TouchableOpacity
                    onPress={() => navigation.goBack()}
                    style={styles.backButton}
                >
                    <Ionicons
                        name="arrow-back"
                        size={30}
                        color="#fff"
                    />
                </TouchableOpacity>

                <Text style={styles.title}>
                    Saída de Estoque
                </Text>

                {/*BOTAO DO QRCODE */}
                <TouchableOpacity
                    style={styles.qrButton}
                    onPress={() => setIsScannerOpen(true)}
                >
                    <Ionicons
                        name="qr-code-outline"
                        size={28}
                        color="#fff"
                    />
                    <Text style={styles.qrText}>
                        Escanear Produto
                    </Text>
                </TouchableOpacity>

                <QRCodeScannerModal
                    visible={isScannerOpen}
                    onClose={() => setIsScannerOpen(false)}
                    onReadCode={handleReadQRCode}
                />

                {/*CARD DO PRODUTO */}
                <View style={styles.productCard}>
                    {product ? (
                        <>
                            <Text style={styles.productName}>
                                {product.name || product.nome}
                            </Text>

                            <Text style={styles.stock}>
                                Código: {product.code || product.id || product.produto_id}
                            </Text>

                            <Text style={styles.stock}>
                                Estoque Atual: {estoqueAtual}
                            </Text>
                        </>
                    ) : (
                        <Text style={styles.productName}>
                            Nenhum produto selecionado
                        </Text>
                    )}
                </View>
                
                {/*QUANTIDADE QUE DESEJA RETIRAR */}
                <Text style={styles.label}>
                    Quantidade de Saída
                </Text>
                
                {/*CAMPO PARA PREENCHER */}
                <TextInput
                    style={styles.input}
                    placeholder="Digite a quantidade"
                    placeholderTextColor="#94A3B8"
                    keyboardType="numeric"
                    value={quantity}
                    onChangeText={setQuantity}
                />
                
                {/*ESTOQUE QUE SOBROU APOS A RETIRADA */}
                <View style={styles.resultCard}>
                    <Text style={styles.resultText}>
                        Estoque Restante
                    </Text>

                    <Text style={styles.resultValue}>
                        {remainingStock < 0 ? 0 : remainingStock}
                    </Text>
                </View>
                
                {/*CONFIRMAR A SAIDA DO PRODUTO ESCOLHIDO */}
                <TouchableOpacity
                    style={styles.confirmButton}
                    onPress={confirmarSaida}
                >
                    <Ionicons
                        name="remove-circle"
                        size={24}
                        color="#fff"
                    />

                    <Text style={styles.confirmText}>
                        Confirmar Saída
                    </Text>
                </TouchableOpacity>

                <View style={{ height: 40 }} />
            </ScrollView>
        </ImageBackground>
    );
}

{/*ESTILO DA INTERFACE */}
const styles = StyleSheet.create({
    background: {
        flex: 1,
    },
    container: {
        flex: 1,
        padding: 20,
    },
    backButton: {
        marginTop: 20,
        alignSelf: 'flex-start',
    },
    title: {
        color: '#fff',
        fontSize: 30,
        fontWeight: 'bold',
        marginTop: 20,
        marginBottom: 30,
    },
    qrButton: {
        backgroundColor: '#3c5fbc',
        height: 70,
        borderRadius: 22,
        flexDirection: 'row',
        justify: 'center',
        alignItems: 'center',
        gap: 10,
    },
    qrText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
    productCard: {
        backgroundColor: '#1E293B',
        borderRadius: 22,
        padding: 25,
        marginTop: 30,
    },
    productName: {
        color: '#fff',
        fontSize: 22,
        fontWeight: 'bold',
    },
    stock: {
        color: '#FF6B6B',
        marginTop: 10,
        fontSize: 15,
        fontWeight: 'bold',
    },
    label: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
        marginTop: 50,
        marginBottom: 15,
    },
    input: {
        backgroundColor: '#1E293B',
        height: 65,
        borderRadius: 18,
        paddingHorizontal: 20,
        color: '#fff',
        fontSize: 18,
    },
    resultCard: {
        backgroundColor: '#3c5fbc',
        borderRadius: 22,
        padding: 25,
        marginTop: 30,
        alignItems: 'center',
    },
    resultText: {
        color: '#ffffff',
        fontSize: 16,
    },
    resultValue: {
        color: '#fff',
        fontSize: 40,
        fontWeight: 'bold',
        marginTop: 10,
    },
    confirmButton: {
        backgroundColor: '#c72f2f',
        height: 65,
        borderRadius: 22,
        marginTop: 35,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 10,
    },
    confirmText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
});